#ifndef VERSION_H_
#define VERSION_H_

#define BL_VERSION_STRING "0.1.0"
#define APP_VERSION_STRING "0.1.0" // MAJOR.MINOR.PATCH

#endif